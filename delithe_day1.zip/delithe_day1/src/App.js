import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Count from './Components/Count'
import './App.css'; 
import CountingFunction from './Components/CountingFunction';
import Timer from './Components/UseEffect';
// import Timer from './Components/UseEffect';

export default function App() {
  return (
    <div className='App'>
      <BrowserRouter>
        <Routes>
          <Route path="/count" element={<Count/>} />
          <Route path="/countFunc" element={<CountingFunction/>} />
          <Route path="/timer" element={<Timer/>} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}
