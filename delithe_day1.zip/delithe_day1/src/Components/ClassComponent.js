import React, { Component } from 'react'

export default class ClassComponent extends Component {
    constructor() {
        super();
        this.message= "hai pawana"
    }
    render() {
        return (
            <div>
                <h1>{this.message}</h1>
            </div>
        )
    }
}
