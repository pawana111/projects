import React from 'react'

function FunctionalDetails(props) {
  return (
    <div>
      <h1>Name{props.Name}</h1>
      <h1>Age{props.Age}</h1>
      <h1>Department{props.Department}</h1>
      <h1>College{props.College}</h1>
    </div>
  )
}

export default FunctionalDetails
