import React from 'react'

function GreetingComponent(props) {
  return (
    <div>
      <h1>Hello good morning{props.name}</h1>
    </div>
  )
}

export default GreetingComponent
