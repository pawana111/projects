import React, { Component } from 'react'

export class FuctionalComponent extends Component {
    constructor(){
        super();
        this.state= {count:0}
    }
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default FuctionalComponent
